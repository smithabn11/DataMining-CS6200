
Submitted Folders & Files: WrittenAnswers.pdf, kNNClassifier, README.txt archived in Smitha_BangaloreNaresh_CS6220_HW2.zip

WrittenAnswers.docx contains written answers.
kNNClassifier contains java files and data to run in eclipse.


How to compile and run :
(NOTE : I could not directly import the project in eclipse as I am 
using jre7 and lab has jre6. I successfully was able to run the project in CS lab.
Follow the steps below.)

Open Eclipse. Create a new java project named kNNClass

1)Copy the files in kNNClassifier/src to kNNClass/src into Eclipse workspace.
2)Copy the lib folder from kNNClassifier/lib to kNNClass/lib (Add weka.jar to build path)
If weka.jar is coming as not found follow the steps to add weka.jar to
this project: http://www.wikihow.com/Add-JARs-to-Project-Build-Paths-in-Eclipse-%28Java%29
Follow Method 1.
3)Copy the data files(train.arff and test.arff) into kNNClass folder.


Output is written to text file named kNNOutput.txt in kNNClass folder.
NOTE : xi is not in accordance to test file. Just printed sequentially to identify the rows easily



