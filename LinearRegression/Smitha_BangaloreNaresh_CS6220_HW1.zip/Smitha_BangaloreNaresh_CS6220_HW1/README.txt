
Submitted Folders: Answers_plots ,LinearRegression, README.txt archived in Smitha_BangaloreNaresh_CS6220_HW1.zip

Answers_plots contains plots and written answers.
LinearRegression contains java files and data to run in eclipse.


How to compile and run :
(NOTE : I could not directly import the project in eclipse as I am 
using jre7 and lab has jre6. I successfully was able to run the project in CS lab.
Follow the steps below.)

Open Eclipse. Create a new java project named LinearReg.

1)Copy the files in LinearRegression/src to LinearReg/src into Eclipse workspace.
2)Copy the lib folder from LinearRegression/lib to LinearReg/lib
If jama.jar is coming as not found follow the steps to add jama.jar to
this project: http://www.wikihow.com/Add-JARs-to-Project-Build-Paths-in-Eclipse-%28Java%29
Follow Method 1.
3)Copy the data files into LinearReg folder.
Now we are ready to run after setting command line arguments.

Set the command line arguments as one of the follows:

To run Q1:
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100	Q1
./train-100-10.csv  , 100 10	./test-100-10.csv  , 1000 10 Q1	
./train-100-100.csv  , 100 100	./test-100-100.csv  , 1000 100 Q1
./50(1000)_100_train.csv , 50 100 ./test-1000-100.csv  , 1000 100 Q1
./100(1000)_100_train.csv , 100 100 ./test-1000-100.csv  , 1000 100 Q1
./150(1000)_100_train.csv , 150 100 ./test-1000-100.csv  , 1000 100 Q1

Output is written to R file. It contains plot of MSE of training and 
testing files for lambda 0 to 150 
(NOTE: R files are generated in current project folder.
And it lab if we dont have RStudio and want to see results change the extension
of file from .R to .txt)
Ex: if we run:
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100	Q1
then the output R file name generated is as follows:
MSE_train-1000-100_test-1000-100.R

To run Q2:
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q2 1
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q2 25
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q2 150

Output is written to R file. It contains plot of Learning curve for a
choosen lambda value.
Ex: if we run
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q2 25
then the output R file name generated is as follows:
LearningCurve_train-1000-100_25.0.R

To run Q3:
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q3 10

Output is written to text file. It contains the lambda values choosen
and corresponding error values. And the best lambda out of them.
Ex: if we run
./train-1000-100.csv , 1000 100	./test-1000-100.csv  , 1000 100 Q3 10
then the output text file name generated is as follows:
CVResult_train-1000-100_FoldVal_10.txt

